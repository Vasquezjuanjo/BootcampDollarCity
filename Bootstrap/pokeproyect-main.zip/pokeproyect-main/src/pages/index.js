export * from './HomePage'
export * from './PokemonPage'
export * from './SearchPage'